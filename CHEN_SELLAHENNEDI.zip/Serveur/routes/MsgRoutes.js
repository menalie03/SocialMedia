const express=require('express');
const router=express.Router();
const MsgModel= require('../models/privateMsgModel');
const ObjectID= require('mongoose').Types.ObjectId;


//-------------------------------------------CHARGER LES MESSAGES PRIVES -----------------------------------------------------
router.get('/show/:user1/:user2', async (req, res)=>{
    if (!ObjectID.isValid(req.params.user1) || !ObjectID.isValid(req.params.user2)){//on vérifie que ID demandé existe bien dans BDD
        return res.status(400).send('one of the users ID is unknown ');
    }
    try{
        const Messages = await MsgModel.find({$or: [{ $and: [{"sender": req.params.user1}, {"receiver": req.params.user2}]}, { $and: [{"sender": req.params.user2}, {"receiver": req.params.user1}]} ]});
        res.status(201).json(Messages);
    }
    catch(err){
        res.status(200).send('Cannot upload the messages' +err);
    }
});


//-------------------------------------------ENVOYER UN MESSAGE PRIVE -----------------------------------------------------
router.post('/send/:sender/:receiver',(req, res)=>{
    if (!ObjectID.isValid(req.params.sender) || !ObjectID.isValid(req.params.receiver)){//on vérifie que ID demandé existe bien dans BDD
        return res.status(400).send('one of the users ID is unknown ');
    }
    if(req.params.sender === req.params.receiver) return res.status(404).send('Cannot send a message to himself');

    const newRecord = new MsgModel({
        // const {author, message}=req.body;   PostModel.create({author,message});
        sender: req.params.sender,
        receiver: req.params.receiver,
        message:req.body.message,
    });

    newRecord.save((err,docs)=>{
        if (!err) res.json ("message sent:"+ {newRecord: newRecord._id});
        else res.send("Error to send the message : " + err);
    })
});

module.exports = router;