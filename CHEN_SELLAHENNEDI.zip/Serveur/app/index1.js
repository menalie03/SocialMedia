const express=require('express');
const path = require("path");

const app=express() //va aller se balader dans la librairie express

const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

//ROUTES

const usersRoutes = require('../routes/usersRoutes');
const postsRoutes = require('../routes/postsRoutes');
const msgRoutes = require('../routes/MsgRoutes');


app.use('/users',usersRoutes);
app.use('/posts',postsRoutes);
app.use('/messages',msgRoutes);


//CONNEXION A LA BASE DE DONNEES
require('../models/dbConfig');
app.listen(5000, ()=>console.log('Serveur pret sur port 5000'));


//petit test 
app.get('/', (req, res) => {
    res.json({user:"Tout va à merveille"})
})


    