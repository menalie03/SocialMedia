import {useState, useEffect} from 'react';
import axios from 'axios';
import './NewSpread.css';

export default function NewSpread(props){
    // const [isloading, setIsLoading] = useState(true);
    const [contenu, setcontenu] = useState('');
    const [postMsg, setPostMsg] = useState("");
    const [postPhoto, setPostPhoto] = useState(null);
    const [file, setFile] = useState();
    const [placeholder, setPlaceholder] = useState('');
    const [reset,setReset] =useState(true);

    useEffect(() => {
      const phrases = ['What a beautiful day               ', 'I am not a big fan of this new social media               ', 'My cat is yellow               ', `SpreadApp c'est pour les nuls               `];
      let count = 0;
      let index = 0;
      let currentPhrase = '';
      let intervalId = setInterval(() => {
        currentPhrase += phrases[count][index];
        setPlaceholder(currentPhrase);
        index++;
        if (index === phrases[count].length) {
          index = 0;
          count++;
          if (count === phrases.length) {
            count = 0;
          }
          currentPhrase = '';
        }
      }, 100);
  
      return () => clearInterval(intervalId);
    }, []);

    function handlecontenuChange(event) {
        setcontenu(event.target.value);
    }
    
    function handleImageChange(event) {
      setPostPhoto(event.target.files[0]);
    }

    const PhotoPic = require('../../Icones/UploadPic.png');

    function handleSubmit(event) {
        event.preventDefault();
        const formData = new FormData();
        if (!postPhoto && !contenu) return;
        if (contenu !== '') formData.append("message", contenu);
        if (postPhoto) {
            formData.append("file", postPhoto);
        }

        axios.post(`http://localhost:5000/posts/${props.user._id}`, formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then((response) => {
          console.log(response);
          props.setReset(!props.reset);
          alert("Spread posté !");
          setcontenu('');
          setPostPhoto(null);
          setFile();
        })
        .catch((error) => {
          console.log(error);
        });
    }

    useEffect(() => {
      if (postPhoto) {
          const reader = new FileReader();
          reader.onload = () => {
              setFile(reader.result);
          };
          reader.readAsDataURL(postPhoto);
      }
    }, [postPhoto]);

    const handleDeletePicButton=()=>{
      setFile();
      setPostPhoto(null);
    }

    return (
        <form onSubmit={handleSubmit} className='form_posting'>
          <textarea id='textareaposting' value={contenu} placeholder={placeholder} onChange={handlecontenuChange} />
          <div className='down-NewSpread'>
              <input type="file" id="upload_NewSpread" onChange={handleImageChange} accept="image/*" style={{ display: "none" }} />
              <img src={PhotoPic} onClick={() => document.getElementById("upload_NewSpread").click()} id='PicUploadIcone'/>

              {file ?
              <div className='img_loaded_NS'>
                <img src={file} alt="selected image" id='selected_image' height='100em'  />
                <button id='buttonforPic' onClick={handleDeletePicButton}>X</button>
              </div>
              : <br/>}
              <button id='buttonposting' type="submit" /*onClick={()=>setReset(!reset)}*/>Post a spread</button>
          </div>
          
        </form>
    );
};