import React from 'react';
import { useState, useEffect } from 'react';
import axios from 'axios';
import './ProfilePics/1.jpg'
import './ProfilePics/2.jpg'
import './ProfilePics/3.jpg'
import './ProfilePics/4.jpg'
import './ProfilePics/5.jpg'
import './ProfilePics/6.jpg'
import './ProfilePics/7.jpg'
import './ProfilePics/8.jpg'
import './ProfilePics/9.jpg'
import './ProfilePics/10.jpg'
import './ProfilePics/11.jpg'
import './ProfilePics/12.jpg'
import './ProfilePics/13.jpg'
import './ProfilePics/14.jpg'


export default function ProfilePic(props){
    const [photo, setPhoto]=useState('');

    const getPicture=()=>{
      axios.get(`http://localhost:5000/pics/${props.user}`)
        .then(res => {
          const profilePicPath = require('./ProfilePics/' + res.data.picture.toString() + '.jpg');
          setPhoto(profilePicPath);
      })
      .catch(error => {
        console.log(error);
      });
    }

    useEffect(() => {
        getPicture();
    }, [photo, props.reset]);

    const nopic=require('./ProfilePics/nopic.jpg');

    return(
        <div className="render_PP">
          {photo===''?
            <img src={nopic} alt='Ma photo' height={props.height} width={props.height}  style={{ borderRadius: '55%', marginLeft: props.marginLeft, marginTop: props.marginTop }}/>
            :
            <img src={photo} alt='Ma photo' height={props.height} width={props.height} style={{ borderRadius: '55%', marginLeft: props.marginLeft, marginTop: props.marginTop }}/>

          }
        </div>
    )
}; 
