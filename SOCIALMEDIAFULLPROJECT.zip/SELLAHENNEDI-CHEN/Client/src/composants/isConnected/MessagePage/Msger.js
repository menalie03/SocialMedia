import React, { useEffect, useState } from "react";
import "./Msger.css"
import axios from "axios";
import ProfilePic from "../ProfilePage/ProfilePic.js"

function Msger(props){
    const [user,setUser]=useState([]);

    useEffect(()=>{
        const friendId=props.msger.members.find(m=>m!==props.currentUser._id);
        const getUser=async()=>{
            try{
            const res=await axios("http://localhost:5000/users/"+friendId);   
            setUser(res.data)
        }catch(err){
        console.log(err);
        }};
        getUser()
    },[props.currentUser, props.msger]);

    useEffect(()=>{
        const friendId=props.msger.members.find(m=>m!==props.currentUser._id);
        const getUser=async()=>{
            try{
            const res=await axios("http://localhost:5000/users/"+friendId);   
            setUser(res.data)
        }catch(err){
        console.log(err);
        }};
        getUser()
    },[]);
    //console.log(user);
    return(
        <div className="messagers">
            
            <div className="ami_cherche">
                <ProfilePic user={user._id} height="50px"  width="50px"/>
                <div className="ami_info">
                <span>{user.nom} {user.prenom}</span>
            </div>
            </div>
        </div>
    )
}

export default Msger