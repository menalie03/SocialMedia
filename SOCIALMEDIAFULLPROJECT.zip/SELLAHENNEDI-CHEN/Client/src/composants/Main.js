import {useState, useEffect} from 'react';
import SignInForm from './isNotConnected/SignInForm.js';
import Header from './isConnected/Header.js';
import axios from 'axios';

function Main(){
    const[page,setPage]=useState("welcome_page");
    const [isConnected, setConnected] = useState(false);
    const [user, setUser]=useState([]);

    function handleLogout(){
        //gestion de la session
        axios.post('http://localhost:5000/session/logout/' + user._id)
        .then(res => {
            console.log('LOGOUT', res.data);
            // localStorage.removeItem('token'); // Supprimer le token
        })
        .catch(error => console.log(error));
    
        setConnected(false);
        setPage("welcome_page");
        console.log(page);
    }
    

    function handleLogin(){

        setConnected(true);
        setPage("home_page");
        console.log(page);
    }

    // useEffect(()=>{

    //         axios.get('http://localhost:5000/session/dashboard')
    //         .then(response => {
    //             if (response.data) {
    //                 setUser(response.data);
    //                 handleLogin();
    //             } else {
    //                 setUser([]);
    //             }
    //         })
    //         .catch(error => {
    //           console.log(error);
    //         });

    // },[]);

// useEffect(()=>{
//     try{
//         axios.get('http://localhost:5000/session/dashboard')
//         .then(res =>{
//             if (res.data){
//                 console.log('USEEFFECT MAIN', res);
//                 const userr =  axios.get('http://localhost:5000/users/' + res.data._id)
//                 .then(rres =>{
//                     setUser(rres.data);
//                     console.log('DASHBOARD', user);
//                     setPage("home_page");
//                 })
                    
//             }else{
//                 setPage("welcome_page");
//             }
//         })    
//     }
//     catch(error) {
//         console.log(error);
//     };
// },[]);

    return(
        <div className="Main">
            {page==="welcome_page"?<SignInForm onLogin={handleLogin} user={user} setUser={setUser} />:<Header type={page} onLogout={handleLogout} user={user} setUser={setUser}/>}
        </div>
    );
};

export default Main;