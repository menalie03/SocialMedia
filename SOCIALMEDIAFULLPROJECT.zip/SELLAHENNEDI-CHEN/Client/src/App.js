import React, {useEffect, useState} from 'react'
//useEffect to fetch the API (=affichage backend)
//cet affichage backend stocké dans des variables pour les mettres dans le frontend

function App() {

  const [backendData,setBackendData] = useState([{}])//état initial: tableau qui contient un object vide

  useEffect(() =>{
    fetch("/api").then(//on peut garder '/api' juste, pas besoin de mettre localhost//5000 avant car on l'a déjà défini devant 'proxy' à la page package.json
      response => response.json() //whatever response we get from the api when we catch it, we're gonna get the response of json
    ).then(//one we get the response
      data =>{//get the data inside the JSON et set in in state
        setBackendData(data)
      }
    )
  },[])//les [] pour faire en sorte que ça run que lors du 1er render
  
  return (
    <div className="App">
      
    </div>
  );
}

export default App;
