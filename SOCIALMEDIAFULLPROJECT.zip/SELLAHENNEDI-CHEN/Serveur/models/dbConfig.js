const mongoose= require('mongoose');
mongoose.set('strictQuery', true);

mongoose.connect(
    //"mongodb://127.0.0.1:27017/node-api", 
    "mongodb+srv://menaliesella:F1gkmYSrbI0Ohuya@cluster0.4fkbssj.mongodb.net/?retryWrites=true&w=majority",
    {useNewUrlParser:true,useUnifiedTopology:true},

    (err)=>{
        if (!err) console.log("Mongodb connected");
        else console.log("Connection error: " + err);
    }
)
