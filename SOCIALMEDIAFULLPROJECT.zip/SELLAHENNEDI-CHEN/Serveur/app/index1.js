const express=require('express');
const path = require("path");
const cookieSession = require('cookie-session');
const app=express() //va aller se balader dans la librairie express

const cors = require('cors');
app.use(cors());

app.use(cookieSession({
    name: 'session',
    keys: ['key1', 'key2']
  }));


const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

//ROUTES
const sessionRoutes = require('../routes/sessionsRoutes');
const usersRoutes = require('../routes/usersRoutes');
const postsRoutes = require('../routes/postsRoutes');
const msgRoutes = require('../routes/MsgRoutes');
const PicsRoutes = require('../routes/profilePicRoutes');
const conRoutes = require("../routes/ConRoutes");

app.use('/session', sessionRoutes);
app.use('/users',usersRoutes);
app.use('/posts',postsRoutes);
app.use('/messages',msgRoutes);
app.use('/pics',PicsRoutes);
app.use('/conversations',conRoutes);

//CONNEXION A LA BASE DE DONNEES
require('../models/dbConfig');
app.listen(5000, ()=>console.log('Serveur pret sur port 5000'));


//petit test 
app.get('/', (req, res) => {
    res.json({user:"Tout va à merveille"})
})


    